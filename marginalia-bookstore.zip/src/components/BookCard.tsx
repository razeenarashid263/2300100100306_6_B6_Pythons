import { Book } from "@/data/books";
import { BookCover } from "./BookCover";
import { Button } from "./ui/button";
import { currency } from "@/lib/format";
import { useCart } from "@/hooks/useCart";
import { toast } from "sonner";

type Props = { book: Book; onOpen: (book: Book) => void };

export const BookCard = ({ book, onOpen }: Props) => {
  const { add } = useCart();

  return (
    <article className="group flex flex-col gap-4">
      <button
        onClick={() => onOpen(book)}
        className="relative block w-full transition-transform duration-500 ease-out hover:-translate-y-1 focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-4 focus-visible:ring-offset-background"
        aria-label={`Open details for ${book.title}`}
      >
        <BookCover book={book} />
      </button>

      <div className="space-y-1">
        <h3 className="font-display text-lg leading-snug text-foreground text-balance">
          {book.title}
        </h3>
        <p className="text-sm text-muted-foreground">
          {book.author} <span className="opacity-60">· {book.year}</span>
        </p>
      </div>

      <div className="mt-auto flex items-center justify-between gap-3">
        <span className="font-display text-lg text-foreground">{currency(book.price)}</span>
        <Button
          size="sm"
          variant="outline"
          className="border-foreground/30 hover:bg-foreground hover:text-background transition-colors"
          onClick={() => {
            add(book);
            toast.success("Added to bag", { description: book.title });
          }}
        >
          Add to bag
        </Button>
      </div>
    </article>
  );
};
