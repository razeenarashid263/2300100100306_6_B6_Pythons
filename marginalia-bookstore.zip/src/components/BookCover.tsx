import { cn } from "@/lib/utils";
import type { Book } from "@/data/books";

type Props = {
  book: Book;
  className?: string;
  size?: "sm" | "md" | "lg";
};

/**
 * Typographic book cover — no image dependencies.
 * Renders a spine + front face with title/author set in display serif.
 */
export const BookCover = ({ book, className, size = "md" }: Props) => {
  const sizes = {
    sm: "text-[10px]",
    md: "text-xs",
    lg: "text-sm",
  };

  const titleSizes = {
    sm: "text-base leading-tight",
    md: "text-lg leading-tight",
    lg: "text-2xl leading-tight",
  };

  return (
    <div
      className={cn(
        "relative aspect-[2/3] w-full overflow-hidden rounded-[2px] book-shadow",
        "bg-gradient-to-br",
        book.cover,
        className,
      )}
    >
      {/* spine highlight */}
      <div className="absolute inset-y-0 left-0 w-[6%] bg-black/30" />
      <div className="absolute inset-y-0 left-[6%] w-[1px] bg-white/15" />

      {/* paper grain on cover */}
      <div className="absolute inset-0 opacity-[0.08] mix-blend-overlay paper-grain" />

      {/* foil border */}
      <div className="absolute inset-2 border border-[hsl(var(--gold)/0.45)] rounded-[1px]" />

      {/* type block */}
      <div className="absolute inset-0 flex flex-col justify-between p-4 pl-[14%] text-[hsl(38_36%_92%)]">
        <div>
          <div className={cn("uppercase tracking-[0.25em] opacity-70", sizes[size])}>
            {book.genre}
          </div>
        </div>

        <div className="space-y-2">
          <div
            className={cn(
              "font-display font-semibold text-balance",
              titleSizes[size],
            )}
            style={{ textShadow: "0 1px 0 rgba(0,0,0,0.25)" }}
          >
            {book.title}
          </div>
          <div className="h-px w-8 bg-[hsl(var(--gold)/0.7)]" />
          <div className={cn("uppercase tracking-[0.2em] opacity-80", sizes[size])}>
            {book.author}
          </div>
        </div>
      </div>

      {/* page edge */}
      <div className="absolute inset-y-0 right-0 w-[3%] bg-gradient-to-l from-black/25 to-transparent" />
    </div>
  );
};
