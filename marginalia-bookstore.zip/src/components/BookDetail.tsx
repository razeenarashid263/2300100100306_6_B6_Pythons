import { Dialog, DialogContent, DialogTitle, DialogDescription } from "./ui/dialog";
import { Book } from "@/data/books";
import { BookCover } from "./BookCover";
import { Button } from "./ui/button";
import { useCart } from "@/hooks/useCart";
import { currency } from "@/lib/format";
import { toast } from "sonner";

type Props = {
  book: Book | null;
  onClose: () => void;
};

export const BookDetail = ({ book, onClose }: Props) => {
  const { add } = useCart();

  return (
    <Dialog open={!!book} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-3xl bg-card border-border p-0 overflow-hidden">
        {book && (
          <div className="grid md:grid-cols-[260px_1fr] gap-0">
            <div className="bg-secondary/60 p-8 flex items-center justify-center">
              <div className="w-full max-w-[200px]">
                <BookCover book={book} size="lg" />
              </div>
            </div>

            <div className="p-8 space-y-5">
              <div className="space-y-2">
                <div className="text-[10px] uppercase tracking-[0.3em] text-accent">
                  {book.genre} · {book.year}
                </div>
                <DialogTitle className="font-display text-3xl text-balance leading-tight">
                  {book.title}
                </DialogTitle>
                <DialogDescription className="text-muted-foreground text-base">
                  by <span className="text-foreground">{book.author}</span>
                </DialogDescription>
              </div>

              <div className="ink-divider" />

              <p className="text-foreground/80 leading-relaxed text-pretty">
                {book.blurb}
              </p>

              <dl className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <dt className="text-muted-foreground text-xs uppercase tracking-wider">Pages</dt>
                  <dd className="font-display text-lg">{book.pages}</dd>
                </div>
                <div>
                  <dt className="text-muted-foreground text-xs uppercase tracking-wider">First published</dt>
                  <dd className="font-display text-lg">{book.year}</dd>
                </div>
              </dl>

              <div className="ink-divider" />

              <div className="flex items-center justify-between gap-4 pt-1">
                <div>
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">Price</div>
                  <div className="font-display text-3xl">{currency(book.price)}</div>
                </div>
                <Button
                  size="lg"
                  className="bg-foreground text-background hover:bg-foreground/90"
                  onClick={() => {
                    add(book);
                    toast.success("Added to bag", { description: book.title });
                  }}
                >
                  Add to bag
                </Button>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
