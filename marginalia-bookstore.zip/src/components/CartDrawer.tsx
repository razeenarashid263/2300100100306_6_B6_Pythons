import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "./ui/sheet";
import { useCart } from "@/hooks/useCart";
import { Button } from "./ui/button";
import { currency } from "@/lib/format";
import { Minus, Plus, X } from "lucide-react";
import { toast } from "sonner";

type Props = { open: boolean; onOpenChange: (o: boolean) => void };

export const CartDrawer = ({ open, onOpenChange }: Props) => {
  const { items, subtotal, setQty, remove, clear, count } = useCart();
  const shipping = subtotal > 0 ? (subtotal > 40 ? 0 : 4.5) : 0;
  const total = subtotal + shipping;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="bg-background border-l border-border w-full sm:max-w-md flex flex-col p-0">
        <SheetHeader className="px-6 pt-6 pb-4 text-left">
          <SheetTitle className="font-display text-2xl">Your bag</SheetTitle>
          <SheetDescription>
            {count === 0 ? "It's quiet in here." : `${count} ${count === 1 ? "book" : "books"} waiting.`}
          </SheetDescription>
        </SheetHeader>

        <div className="ink-divider mx-6" />

        <div className="flex-1 overflow-y-auto px-6 py-4">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center gap-3 py-16">
              <div className="font-display text-xl text-muted-foreground">No books yet</div>
              <p className="text-sm text-muted-foreground max-w-xs">
                Browse the shelf and add a few volumes — they'll wait here for you.
              </p>
            </div>
          ) : (
            <ul className="divide-y divide-border">
              {items.map(({ book, qty }) => (
                <li key={book.id} className="py-4 flex gap-4">
                  <div className={`w-14 h-20 rounded-[2px] bg-gradient-to-br ${book.cover} flex-shrink-0 soft-shadow`} />
                  <div className="flex-1 min-w-0 flex flex-col">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="font-display text-base leading-tight truncate">{book.title}</div>
                        <div className="text-xs text-muted-foreground truncate">{book.author}</div>
                      </div>
                      <button
                        onClick={() => remove(book.id)}
                        className="text-muted-foreground hover:text-foreground transition-colors p-1 -m-1"
                        aria-label="Remove"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="mt-auto flex items-center justify-between pt-2">
                      <div className="flex items-center border border-border rounded-sm">
                        <button
                          onClick={() => setQty(book.id, qty - 1)}
                          className="p-1.5 hover:bg-secondary transition-colors"
                          aria-label="Decrease"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-8 text-center text-sm tabular-nums">{qty}</span>
                        <button
                          onClick={() => setQty(book.id, qty + 1)}
                          className="p-1.5 hover:bg-secondary transition-colors"
                          aria-label="Increase"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                      <div className="font-display text-base">{currency(book.price * qty)}</div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {items.length > 0 && (
          <div className="border-t border-border px-6 py-5 space-y-4 bg-secondary/30">
            <div className="space-y-1.5 text-sm">
              <div className="flex justify-between text-muted-foreground">
                <span>Subtotal</span>
                <span className="tabular-nums">{currency(subtotal)}</span>
              </div>
              <div className="flex justify-between text-muted-foreground">
                <span>Shipping {shipping === 0 && subtotal > 0 && <em className="not-italic text-accent">· free</em>}</span>
                <span className="tabular-nums">{shipping === 0 ? "—" : currency(shipping)}</span>
              </div>
              <div className="ink-divider my-2" />
              <div className="flex justify-between font-display text-lg">
                <span>Total</span>
                <span className="tabular-nums">{currency(total)}</span>
              </div>
            </div>
            <Button
              className="w-full bg-foreground text-background hover:bg-foreground/90 h-11"
              onClick={() => {
                toast.success("Order placed (demo)", {
                  description: "Checkout & payments aren't wired yet — we can add them next.",
                });
                clear();
                onOpenChange(false);
              }}
            >
              Checkout
            </Button>
            <button
              onClick={clear}
              className="w-full text-xs uppercase tracking-wider text-muted-foreground hover:text-foreground transition-colors"
            >
              Clear bag
            </button>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
};
