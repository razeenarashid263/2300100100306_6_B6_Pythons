export const Footer = () => {
  return (
    <footer id="about" className="border-t border-border mt-20">
      <div className="container py-16 grid md:grid-cols-3 gap-10">
        <div className="space-y-3 md:col-span-2">
          <div className="font-display text-2xl">
            Marginalia<span className="text-accent">.</span>
          </div>
          <p className="text-muted-foreground max-w-md text-pretty leading-relaxed">
            A tiny independent bookshop on the internet. We read everything we sell,
            and we'd rather recommend one perfect book than a hundred good ones.
          </p>
        </div>
        <div className="space-y-3 text-sm">
          <div className="text-xs uppercase tracking-[0.25em] text-muted-foreground">Visit</div>
          <address className="not-italic text-foreground/80 leading-relaxed">
            14 Quill Lane<br />
            Open Wed — Sun, 11–7<br />
            <a href="mailto:hello@marginalia.shop" className="hover:text-accent transition-colors">
              hello@marginalia.shop
            </a>
          </address>
        </div>
      </div>
      <div className="border-t border-border">
        <div className="container py-5 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-muted-foreground">
          <span>© {new Date().getFullYear()} Marginalia Books</span>
          <span className="font-display italic">"A book is a heart that only beats in the chest of another." — Rebecca Solnit</span>
        </div>
      </div>
    </footer>
  );
};
