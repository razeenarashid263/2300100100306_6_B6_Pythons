import { genres, type Genre } from "@/data/books";
import { cn } from "@/lib/utils";

type Props = { value: Genre; onChange: (g: Genre) => void };

export const GenreFilter = ({ value, onChange }: Props) => {
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      {genres.map((g) => {
        const active = g === value;
        return (
          <button
            key={g}
            onClick={() => onChange(g)}
            className={cn(
              "text-xs uppercase tracking-[0.2em] px-3 h-8 rounded-sm border transition-colors",
              active
                ? "bg-foreground text-background border-foreground"
                : "border-border text-muted-foreground hover:text-foreground hover:border-foreground/40",
            )}
          >
            {g}
          </button>
        );
      })}
    </div>
  );
};
