import { Search, ShoppingBag } from "lucide-react";
import { Input } from "./ui/input";
import { useCart } from "@/hooks/useCart";

type Props = {
  query: string;
  onQuery: (q: string) => void;
  onOpenCart: () => void;
};

export const Header = ({ query, onQuery, onOpenCart }: Props) => {
  const { count } = useCart();

  return (
    <header className="sticky top-0 z-30 backdrop-blur-md bg-background/80 border-b border-border">
      <div className="container flex items-center gap-4 h-16">
        <a href="/" className="flex items-center gap-2 group">
          <div className="w-8 h-8 rounded-sm bg-foreground text-background grid place-items-center font-display font-bold text-lg leading-none">
            M
          </div>
          <div className="font-display text-xl tracking-tight">
            Marginalia<span className="text-accent">.</span>
          </div>
        </a>

        <div className="hidden md:flex flex-1 max-w-md mx-auto relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
          <Input
            value={query}
            onChange={(e) => onQuery(e.target.value)}
            placeholder="Search by title or author…"
            className="pl-9 bg-secondary/60 border-transparent focus-visible:bg-background focus-visible:border-border h-10"
          />
        </div>

        <div className="flex-1 md:hidden" />

        <nav className="flex items-center gap-1">
          <button
            onClick={onOpenCart}
            className="relative inline-flex items-center gap-2 px-3 h-10 rounded-sm text-sm hover:bg-secondary transition-colors"
            aria-label="Open bag"
          >
            <ShoppingBag className="w-4 h-4" />
            <span className="hidden sm:inline">Bag</span>
            {count > 0 && (
              <span className="absolute -top-1 -right-1 sm:static sm:ml-1 min-w-5 h-5 px-1.5 grid place-items-center rounded-full bg-accent text-accent-foreground text-[10px] font-medium tabular-nums">
                {count}
              </span>
            )}
          </button>
        </nav>
      </div>

      <div className="md:hidden container pb-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
          <Input
            value={query}
            onChange={(e) => onQuery(e.target.value)}
            placeholder="Search by title or author…"
            className="pl-9 bg-secondary/60 border-transparent h-10"
          />
        </div>
      </div>
    </header>
  );
};
