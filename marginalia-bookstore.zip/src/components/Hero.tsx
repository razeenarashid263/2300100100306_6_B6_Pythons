import { books } from "@/data/books";
import { BookCover } from "./BookCover";

export const Hero = () => {
  // Pick a few books to fan out as a still-life
  const featured = [books[1], books[6], books[9], books[3]];

  return (
    <section className="relative overflow-hidden border-b border-border">
      <div className="container py-16 md:py-24 grid md:grid-cols-2 gap-12 md:gap-8 items-center">
        <div className="space-y-6 animate-fade-up">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.3em] text-accent">
            <span className="w-8 h-px bg-accent" />
            Est. an afternoon ago
          </div>
          <h1 className="font-display text-5xl md:text-7xl leading-[0.95] text-balance">
            A small shelf<br />
            of <em className="italic text-accent">extraordinary</em><br />
            books.
          </h1>
          <p className="text-lg text-muted-foreground max-w-md text-pretty leading-relaxed">
            Hand-picked fiction, essays, and poetry. No bestsellers chart, no
            algorithm — just titles we'd press into a friend's hands.
          </p>
          <div className="flex items-center gap-4 pt-2">
            <a
              href="#shelf"
              className="inline-flex items-center gap-2 px-5 h-11 rounded-sm bg-foreground text-background text-sm hover:bg-foreground/90 transition-colors"
            >
              Browse the shelf
            </a>
            <a
              href="#about"
              className="inline-flex items-center gap-2 px-5 h-11 rounded-sm border border-border text-sm hover:bg-secondary transition-colors"
            >
              Our story
            </a>
          </div>
        </div>

        <div className="relative h-[360px] md:h-[480px] hidden md:block">
          {featured.map((b, i) => {
            const positions = [
              "left-2 top-6 rotate-[-8deg] z-10",
              "left-24 top-0 rotate-[-2deg] z-20",
              "left-48 top-10 rotate-[3deg] z-30",
              "left-72 top-2 rotate-[8deg] z-20",
            ];
            return (
              <div
                key={b.id}
                className={`absolute w-44 transition-transform duration-700 ease-out hover:-translate-y-2 ${positions[i]}`}
                style={{ animation: `fade-up 0.8s ${i * 0.12}s both` }}
              >
                <BookCover book={b} />
              </div>
            );
          })}

          {/* shelf */}
          <div className="absolute bottom-0 left-0 right-0 h-3 bg-gradient-to-b from-[hsl(28_30%_42%)] to-[hsl(28_35%_28%)] rounded-sm soft-shadow" />
          <div className="absolute bottom-3 left-2 right-2 h-1 bg-black/30 blur-sm" />
        </div>
      </div>
    </section>
  );
};
