export type Book = {
  id: string;
  title: string;
  author: string;
  year: number;
  price: number;
  genre: "Fiction" | "Non-fiction" | "Poetry" | "Classics" | "Sci-Fi";
  cover: string; // tailwind gradient classes
  spine: string; // accent color class for the spine
  blurb: string;
  pages: number;
};

// Curated catalog. Covers are rendered as typographic compositions (no image deps).
export const books: Book[] = [
  {
    id: "1",
    title: "The Sea, the Sea",
    author: "Iris Murdoch",
    year: 1978,
    price: 18,
    genre: "Classics",
    cover: "from-[hsl(200_40%_22%)] to-[hsl(200_30%_12%)]",
    spine: "bg-[hsl(200_40%_22%)]",
    blurb:
      "A retired theatre director retreats to a remote seaside house and finds his solitude unraveled by the past.",
    pages: 538,
  },
  {
    id: "2",
    title: "Beloved",
    author: "Toni Morrison",
    year: 1987,
    price: 16,
    genre: "Fiction",
    cover: "from-[hsl(14_60%_28%)] to-[hsl(14_50%_16%)]",
    spine: "bg-[hsl(14_60%_28%)]",
    blurb:
      "A staggering, lyrical novel about memory, motherhood, and the long shadow of slavery in post–Civil War Ohio.",
    pages: 324,
  },
  {
    id: "3",
    title: "Pale Fire",
    author: "Vladimir Nabokov",
    year: 1962,
    price: 17,
    genre: "Classics",
    cover: "from-[hsl(38_50%_40%)] to-[hsl(28_45%_22%)]",
    spine: "bg-[hsl(38_50%_40%)]",
    blurb:
      "A 999-line poem and a deranged commentary collide into one of the most playful novels of the 20th century.",
    pages: 315,
  },
  {
    id: "4",
    title: "A Little Life",
    author: "Hanya Yanagihara",
    year: 2015,
    price: 22,
    genre: "Fiction",
    cover: "from-[hsl(220_25%_22%)] to-[hsl(220_20%_10%)]",
    spine: "bg-[hsl(220_25%_22%)]",
    blurb:
      "Four friends in New York carry one extraordinary, irreparable secret across decades.",
    pages: 736,
  },
  {
    id: "5",
    title: "The Argonauts",
    author: "Maggie Nelson",
    year: 2015,
    price: 15,
    genre: "Non-fiction",
    cover: "from-[hsl(340_30%_30%)] to-[hsl(340_25%_16%)]",
    spine: "bg-[hsl(340_30%_30%)]",
    blurb:
      "A genre-bending memoir of family-making, queer love, and the limits of language.",
    pages: 160,
  },
  {
    id: "6",
    title: "Stoner",
    author: "John Williams",
    year: 1965,
    price: 14,
    genre: "Classics",
    cover: "from-[hsl(28_45%_30%)] to-[hsl(28_35%_16%)]",
    spine: "bg-[hsl(28_45%_30%)]",
    blurb:
      "A quiet life of an American academic, told with such grace it has become a modern masterpiece.",
    pages: 288,
  },
  {
    id: "7",
    title: "Piranesi",
    author: "Susanna Clarke",
    year: 2020,
    price: 16,
    genre: "Fiction",
    cover: "from-[hsl(190_35%_28%)] to-[hsl(190_30%_14%)]",
    spine: "bg-[hsl(190_35%_28%)]",
    blurb:
      "In a vast house of statues and tides, a man records his world — until a stranger arrives.",
    pages: 272,
  },
  {
    id: "8",
    title: "On Photography",
    author: "Susan Sontag",
    year: 1977,
    price: 14,
    genre: "Non-fiction",
    cover: "from-[hsl(0_0%_18%)] to-[hsl(0_0%_8%)]",
    spine: "bg-[hsl(0_0%_18%)]",
    blurb:
      "Six essays that reshaped how we look at images — and at the world they claim to record.",
    pages: 207,
  },
  {
    id: "9",
    title: "Wolf Hall",
    author: "Hilary Mantel",
    year: 2009,
    price: 19,
    genre: "Fiction",
    cover: "from-[hsl(355_45%_30%)] to-[hsl(355_40%_16%)]",
    spine: "bg-[hsl(355_45%_30%)]",
    blurb:
      "Thomas Cromwell rises through the Tudor court in a novel of dazzling intimacy and intelligence.",
    pages: 650,
  },
  {
    id: "10",
    title: "Devotions",
    author: "Mary Oliver",
    year: 2017,
    price: 20,
    genre: "Poetry",
    cover: "from-[hsl(150_25%_24%)] to-[hsl(150_20%_12%)]",
    spine: "bg-[hsl(150_25%_24%)]",
    blurb:
      "Fifty years of poems gathered by the poet herself — a luminous companion for any season.",
    pages: 480,
  },
  {
    id: "11",
    title: "The Left Hand of Darkness",
    author: "Ursula K. Le Guin",
    year: 1969,
    price: 15,
    genre: "Sci-Fi",
    cover: "from-[hsl(230_30%_22%)] to-[hsl(230_25%_10%)]",
    spine: "bg-[hsl(230_30%_22%)]",
    blurb:
      "An envoy from a galactic federation arrives on a world where gender is fluid and winter is endless.",
    pages: 304,
  },
  {
    id: "12",
    title: "Bluets",
    author: "Maggie Nelson",
    year: 2009,
    price: 13,
    genre: "Poetry",
    cover: "from-[hsl(215_55%_32%)] to-[hsl(215_50%_18%)]",
    spine: "bg-[hsl(215_55%_32%)]",
    blurb:
      "240 propositions on the color blue — and on grief, love, and looking closely.",
    pages: 112,
  },
  {
    id: "13",
    title: "The Overstory",
    author: "Richard Powers",
    year: 2018,
    price: 18,
    genre: "Fiction",
    cover: "from-[hsl(95_25%_24%)] to-[hsl(95_20%_12%)]",
    spine: "bg-[hsl(95_25%_24%)]",
    blurb:
      "Nine strangers, summoned in different ways by trees, weave into a sweeping ecological epic.",
    pages: 502,
  },
  {
    id: "14",
    title: "Just Kids",
    author: "Patti Smith",
    year: 2010,
    price: 16,
    genre: "Non-fiction",
    cover: "from-[hsl(0_0%_22%)] to-[hsl(0_0%_10%)]",
    spine: "bg-[hsl(0_0%_22%)]",
    blurb:
      "A tender, electric memoir of New York, of art, and of her years with Robert Mapplethorpe.",
    pages: 304,
  },
  {
    id: "15",
    title: "The Dispossessed",
    author: "Ursula K. Le Guin",
    year: 1974,
    price: 15,
    genre: "Sci-Fi",
    cover: "from-[hsl(35_55%_38%)] to-[hsl(35_45%_20%)]",
    spine: "bg-[hsl(35_55%_38%)]",
    blurb:
      "An anarchist physicist crosses between two worlds in a novel about freedom, walls, and time.",
    pages: 387,
  },
  {
    id: "16",
    title: "If Not, Winter",
    author: "Sappho / Anne Carson",
    year: 2002,
    price: 17,
    genre: "Poetry",
    cover: "from-[hsl(45_55%_42%)] to-[hsl(35_50%_24%)]",
    spine: "bg-[hsl(45_55%_42%)]",
    blurb:
      "Anne Carson's translation of Sappho's fragments — what survives of the great lyric poet.",
    pages: 416,
  },
];

export const genres = ["All", "Fiction", "Non-fiction", "Classics", "Poetry", "Sci-Fi"] as const;
export type Genre = (typeof genres)[number];
