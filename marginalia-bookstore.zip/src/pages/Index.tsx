import { useMemo, useState } from "react";
import { books, type Genre } from "@/data/books";
import { CartProvider } from "@/hooks/useCart";
import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { BookCard } from "@/components/BookCard";
import { GenreFilter } from "@/components/GenreFilter";
import { BookDetail } from "@/components/BookDetail";
import { CartDrawer } from "@/components/CartDrawer";
import { Footer } from "@/components/Footer";
import type { Book } from "@/data/books";

const Bookstore = () => {
  const [query, setQuery] = useState("");
  const [genre, setGenre] = useState<Genre>("All");
  const [active, setActive] = useState<Book | null>(null);
  const [cartOpen, setCartOpen] = useState(false);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return books.filter((b) => {
      const matchesGenre = genre === "All" || b.genre === genre;
      const matchesQuery =
        !q || b.title.toLowerCase().includes(q) || b.author.toLowerCase().includes(q);
      return matchesGenre && matchesQuery;
    });
  }, [query, genre]);

  return (
    <div className="min-h-screen flex flex-col">
      <Header query={query} onQuery={setQuery} onOpenCart={() => setCartOpen(true)} />

      <main className="flex-1">
        <Hero />

        <section id="shelf" className="container py-14 md:py-20">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-10">
            <div className="space-y-2">
              <div className="text-xs uppercase tracking-[0.3em] text-accent">The shelf</div>
              <h2 className="font-display text-3xl md:text-4xl text-balance">
                {filtered.length} {filtered.length === 1 ? "title" : "titles"} in stock
              </h2>
            </div>
            <GenreFilter value={genre} onChange={setGenre} />
          </div>

          {filtered.length === 0 ? (
            <div className="py-24 text-center space-y-2">
              <div className="font-display text-2xl">Nothing on this shelf.</div>
              <p className="text-muted-foreground">Try another genre or a different search.</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-12">
              {filtered.map((b) => (
                <BookCard key={b.id} book={b} onOpen={setActive} />
              ))}
            </div>
          )}
        </section>
      </main>

      <Footer />

      <BookDetail book={active} onClose={() => setActive(null)} />
      <CartDrawer open={cartOpen} onOpenChange={setCartOpen} />
    </div>
  );
};

const Index = () => (
  <CartProvider>
    <Bookstore />
  </CartProvider>
);

export default Index;
